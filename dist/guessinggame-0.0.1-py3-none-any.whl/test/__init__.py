"""Test Package for Guessing game.

Author:John Jalali jjalali@ksu.edu
Version: 0.1
"""
